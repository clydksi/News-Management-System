<?php
// Google News RSS Dashboard – Enhanced Purple Edition
// All backend/JS logic preserved, full UI redesign

if (isset($_GET['debug']) && $_GET['debug'] === 'view-html') {
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: text/html; charset=utf-8');
    $googleNewsUrl = isset($_GET['url']) ? $_GET['url'] : '';
    if (empty($googleNewsUrl)) { echo "No URL provided. Usage: ?debug=view-html&url=GOOGLE_NEWS_URL"; exit(); }
    $ch = curl_init();
    curl_setopt_array($ch, [CURLOPT_URL => $googleNewsUrl, CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36']);
    $html = curl_exec($ch);
    $finalUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);
    echo "<h1>Debug: Google News HTML</h1>";
    echo "<p><strong>Original URL:</strong> " . htmlspecialchars($googleNewsUrl) . "</p>";
    echo "<p><strong>Final URL:</strong> " . htmlspecialchars($finalUrl) . "</p>";
    echo "<hr><h2>Raw HTML:</h2><pre>" . htmlspecialchars($html) . "</pre>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live News Feed · Philippines</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Sora:wght@300;400;500;600&family=Fira+Code:wght@400;500&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet"/>
    <style>
    /* ═══ Tokens ════════════════════════════════════════════════════ */
    :root {
        --purple:        #7C3AED;
        --purple-md:     #6D28D9;
        --purple-dark:   #4C1D95;
        --purple-light:  #EDE9FE;
        --purple-pale:   #F5F3FF;
        --purple-glow:   rgba(124,58,237,.18);

        --ink:           #13111A;
        --ink-muted:     #4A4560;
        --ink-faint:     #8E89A8;

        --canvas:        #F3F1FA;
        --surface:       #FFFFFF;
        --surface-2:     #EEEAF8;

        --border:        #E2DDEF;
        --border-md:     #C9C2E0;

        --sidebar-bg:    #130F23;
        --sidebar-text:  #D4CFE8;
        --sidebar-muted: #6B6485;
        --sidebar-act:   rgba(124,58,237,.18);

        --hot:           #EF4444;
        --trending:      #F59E0B;
        --rising:        #3B82F6;

        --success-bg:    #ECFDF5; --success-text: #065F46; --success-bd: #A7F3D0;
        --error-bg:      #FFF1F2; --error-text:   #9F1239; --error-bd:   #FECDD3;
        --warn-bg:       #FFFBEB; --warn-text:    #92400E; --warn-bd:    #FDE68A;
        --info-bg:       #F5F3FF; --info-text:    #5B21B6; --info-bd:    #C4B5FD;

        --r:    12px;
        --r-sm: 7px;
        --sh:   0 1px 3px rgba(60,20,120,.07), 0 1px 2px rgba(60,20,120,.05);
        --sh-md:0 4px 14px rgba(60,20,120,.10), 0 2px 4px rgba(60,20,120,.06);
        --sh-lg:0 14px 40px rgba(60,20,120,.16), 0 4px 8px rgba(60,20,120,.08);
    }
    [data-theme="dark"] {
        --ink:         #EAE6F8;
        --ink-muted:   #9E98B8;
        --ink-faint:   #635D7A;
        --canvas:      #0E0C18;
        --surface:     #17142A;
        --surface-2:   #1E1A30;
        --border:      #2A2540;
        --border-md:   #362F50;
        --purple-light:#1E1440;
        --purple-pale: #150F2E;
        --sidebar-bg:  #0A0815;
        --sh:    0 1px 3px rgba(0,0,0,.4);
        --sh-md: 0 4px 14px rgba(0,0,0,.45);
        --sh-lg: 0 14px 40px rgba(0,0,0,.55);
    }

    /* ═══ Reset ══════════════════════════════════════════════════════ */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    html { height: 100%; scroll-behavior: smooth; }
    body {
        font-family: 'Sora', sans-serif;
        background: var(--canvas);
        color: var(--ink);
        min-height: 100%;
    }
    ::-webkit-scrollbar { width: 5px; height: 5px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: var(--border-md); border-radius: 99px; }

    /* ═══ Header / Command Bar ═══════════════════════════════════════ */
    .topbar {
        position: sticky; top: 0; z-index: 80;
        background: var(--sidebar-bg);
        border-bottom: 1px solid rgba(255,255,255,.06);
        height: 60px;
        display: flex; align-items: center;
        padding: 0 24px; gap: 14px;
    }
    .brand {
        display: flex; align-items: center; gap: 10px;
        text-decoration: none; flex-shrink: 0;
    }
    .brand-mark {
        width: 34px; height: 34px;
        background: var(--purple);
        border-radius: 8px;
        display: flex; align-items: center; justify-content: center;
    }
    .brand-mark .material-icons-round { font-size: 18px !important; color: white; }
    .brand-name {
        font-family: 'Playfair Display', serif;
        font-size: 16px; font-weight: 700; color: #EAE6F8;
        white-space: nowrap;
    }
    .brand-sub { font-size: 10px; color: var(--sidebar-muted); display: block; line-height: 1; letter-spacing: .08em; }

    .topbar-search {
        flex: 1; max-width: 400px;
        position: relative;
    }
    .topbar-search input {
        width: 100%;
        background: rgba(255,255,255,.07);
        border: 1px solid rgba(255,255,255,.1);
        border-radius: 99px;
        padding: 7px 14px 7px 36px;
        font-family: 'Sora', sans-serif;
        font-size: 13px; color: var(--sidebar-text);
        outline: none; transition: border-color .15s, box-shadow .15s;
    }
    .topbar-search input:focus {
        border-color: var(--purple);
        box-shadow: 0 0 0 3px var(--purple-glow);
    }
    .topbar-search input::placeholder { color: var(--sidebar-muted); }
    .topbar-search .s-icon {
        position: absolute; left: 11px; top: 50%; transform: translateY(-50%);
        color: var(--sidebar-muted); font-size: 16px !important; pointer-events: none;
    }

    .topbar-right { margin-left: auto; display: flex; align-items: center; gap: 8px; }

    .tb-btn {
        display: inline-flex; align-items: center; gap: 5px;
        padding: 6px 12px;
        border-radius: var(--r-sm);
        font-family: 'Sora', sans-serif;
        font-size: 12px; font-weight: 500;
        cursor: pointer; border: none; white-space: nowrap;
        transition: all .15s; text-decoration: none;
    }
    .tb-btn .material-icons-round { font-size: 15px !important; }
    .tb-btn-purple { background: var(--purple); color: white; }
    .tb-btn-purple:hover { background: var(--purple-md); box-shadow: 0 3px 10px var(--purple-glow); }
    .tb-btn-ghost  { background: rgba(255,255,255,.08); color: var(--sidebar-text); border: 1px solid rgba(255,255,255,.1); }
    .tb-btn-ghost:hover  { background: rgba(255,255,255,.14); }
    .tb-btn-icon {
        width: 32px; height: 32px; padding: 0;
        display: flex; align-items: center; justify-content: center;
        border-radius: var(--r-sm);
    }

    .live-pill {
        display: inline-flex; align-items: center; gap: 5px;
        padding: 4px 9px;
        background: rgba(239,68,68,.15);
        border: 1px solid rgba(239,68,68,.3);
        border-radius: 99px;
        font-size: 10px; font-weight: 600; color: #FCA5A5;
        font-family: 'Fira Code', monospace;
        letter-spacing: .05em;
    }
    .live-dot {
        width: 6px; height: 6px; border-radius: 50%;
        background: #EF4444;
        animation: livePulse 2s ease-in-out infinite;
    }
    @keyframes livePulse { 0%,100%{opacity:1} 50%{opacity:.4} }

    /* ═══ Filter Bar ════════════════════════════════════════════════ */
    .filter-bar {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
        box-shadow: var(--sh);
        position: sticky; top: 60px; z-index: 70;
    }
    .filter-inner {
        max-width: 1440px; margin: 0 auto;
        padding: 10px 24px;
        display: flex; gap: 8px; align-items: center; flex-wrap: wrap;
    }
    .filter-divider { width: 1px; height: 26px; background: var(--border); flex-shrink: 0; margin: 0 4px; }

    /* Category chips */
    .cat-chip {
        display: inline-flex; align-items: center; gap: 5px;
        padding: 6px 13px;
        background: var(--canvas);
        border: 1px solid var(--border);
        border-radius: 99px;
        font-family: 'Sora', sans-serif;
        font-size: 12px; font-weight: 500;
        color: var(--ink-muted);
        cursor: pointer; transition: all .15s;
        white-space: nowrap;
    }
    .cat-chip:hover { border-color: var(--purple); color: var(--purple); background: var(--purple-pale); }
    .cat-chip.active { background: var(--purple); border-color: var(--purple); color: white; box-shadow: 0 2px 8px var(--purple-glow); }
    .cat-chip .material-icons-round { font-size: 14px !important; }

    /* Trending chip special */
    .cat-chip.hot {
        background: linear-gradient(135deg, #EF4444, #DC2626);
        border-color: transparent; color: white;
        animation: hotGlow 2s ease-in-out infinite;
    }
    .cat-chip.hot:hover { background: linear-gradient(135deg, #DC2626, #B91C1C); }
    .cat-chip.hot.active { box-shadow: 0 2px 12px rgba(239,68,68,.45); }
    @keyframes hotGlow {
        0%,100%{box-shadow:0 2px 8px rgba(239,68,68,.3)}
        50%{box-shadow:0 4px 16px rgba(239,68,68,.55)}
    }

    /* Location chips */
    .loc-chip {
        display: inline-flex; align-items: center; gap: 4px;
        padding: 5px 11px;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 99px;
        font-size: 11px; font-weight: 500; color: var(--ink-faint);
        cursor: pointer; transition: all .15s;
    }
    .loc-chip:hover { border-color: var(--purple); color: var(--purple); }
    .loc-chip.active { background: var(--purple-light); border-color: var(--purple); color: var(--purple); font-weight: 600; }
    .loc-chip.disabled { opacity: .4; pointer-events: none; cursor: not-allowed; }

    /* ═══ Stats Strip ═══════════════════════════════════════════════ */
    .stats-strip {
        background: var(--surface);
        border-bottom: 1px solid var(--border);
    }
    .stats-inner {
        max-width: 1440px; margin: 0 auto;
        padding: 8px 24px;
        display: flex; align-items: center; justify-content: space-between;
        gap: 16px; flex-wrap: wrap;
    }
    .stats-left { display: flex; align-items: center; gap: 20px; flex-wrap: wrap; }
    .stat-item {
        display: flex; align-items: center; gap: 5px;
        font-size: 12px; color: var(--ink-faint);
        font-family: 'Fira Code', monospace;
    }
    .stat-item .material-icons-round { font-size: 13px !important; }
    .stat-item strong { color: var(--ink); }

    .filter-badge {
        display: inline-flex; align-items: center; gap: 6px;
        padding: 4px 12px;
        background: var(--purple-light);
        border: 1px solid var(--info-bd);
        border-radius: 99px;
        font-size: 11px; font-weight: 600; color: var(--purple-md);
    }

    .per-page-wrap { display: flex; align-items: center; gap: 7px; }
    .per-page-wrap label { font-size: 12px; color: var(--ink-faint); }
    .per-page-wrap select {
        padding: 4px 22px 4px 9px;
        border: 1px solid var(--border);
        border-radius: var(--r-sm);
        background: var(--canvas);
        font-family: 'Sora', sans-serif;
        font-size: 12px; color: var(--ink);
        cursor: pointer; outline: none;
        -webkit-appearance: none; appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 24 24'%3E%3Cpath fill='%238E89A8' d='M7 10l5 5 5-5z'/%3E%3C/svg%3E");
        background-repeat: no-repeat; background-position: right 6px center;
    }
    .per-page-wrap select:focus { border-color: var(--purple); }

    /* ═══ Main Container ════════════════════════════════════════════ */
    .page-wrap { max-width: 1440px; margin: 0 auto; padding: 22px 24px 60px; }

    /* ═══ Loading ════════════════════════════════════════════════════ */
    .loading-state {
        display: flex; flex-direction: column; align-items: center;
        justify-content: center;
        padding: 80px 24px;
        text-align: center;
    }
    .loading-ring {
        width: 52px; height: 52px;
        border: 4px solid var(--border);
        border-top-color: var(--purple);
        border-radius: 50%;
        animation: spin .9s linear infinite;
        margin-bottom: 20px;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    .loading-label {
        font-size: 14px; color: var(--ink-muted); font-weight: 500;
        line-height: 1.6;
    }
    .loading-label span { color: var(--purple); font-weight: 600; }

    /* ═══ News Grid ══════════════════════════════════════════════════ */
    .news-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
        gap: 18px;
    }

    /* ═══ News Card ══════════════════════════════════════════════════ */
    .news-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--r);
        overflow: hidden;
        box-shadow: var(--sh);
        cursor: pointer;
        transition: transform .2s, box-shadow .2s, border-color .2s;
        display: flex; flex-direction: column;
        position: relative;
    }
    .news-card:hover {
        transform: translateY(-3px);
        box-shadow: var(--sh-lg);
        border-color: var(--border-md);
    }

    .card-img-wrap {
        height: 200px; position: relative; overflow: hidden;
        background: linear-gradient(135deg, var(--purple-light), var(--surface-2));
        flex-shrink: 0;
    }
    .card-img-wrap img { width:100%; height:100%; object-fit:cover; transition:transform .4s; }
    .news-card:hover .card-img-wrap img { transform:scale(1.04); }
    .img-placeholder {
        width:100%; height:100%;
        display:flex; align-items:center; justify-content:center;
    }
    .img-placeholder .material-icons-round { font-size:48px!important; color:var(--border-md); }
    .img-veil {
        position:absolute; bottom:0; left:0; right:0; height:70px;
        background:linear-gradient(to top,rgba(19,17,26,.5),transparent);
        pointer-events:none;
    }

    /* Trending badge overlay */
    .badge-overlay {
        position:absolute; top:10px; left:10px;
        display:flex; flex-direction:column; gap:5px;
        z-index:5;
    }
    .ov-badge {
        display:inline-flex; align-items:center; gap:4px;
        padding:4px 9px;
        border-radius:6px;
        font-size:10px; font-weight:700;
        text-transform:uppercase; letter-spacing:.06em;
    }
    .ov-badge.hot      { background: rgba(239,68,68,.92); color:white; }
    .ov-badge.trending { background: rgba(245,158,11,.92); color:white; }
    .ov-badge.rising   { background: rgba(59,130,246,.92); color:white; }
    .ov-badge.related  { background: rgba(124,58,237,.92); color:white; }
    .ov-badge .material-icons-round { font-size:11px!important; }

    /* Source reference banner */
    .src-ref-banner {
        position:absolute; bottom:0; left:0; right:0;
        background: linear-gradient(135deg, rgba(245,158,11,.92), rgba(217,119,6,.92));
        padding:7px 11px;
        display:flex; align-items:center; gap:6px;
        font-size:11px; font-weight:600; color:white;
        animation:refBlink 1.8s ease-in-out infinite;
        z-index:5;
    }
    .src-ref-banner .material-icons-round { font-size:13px!important; flex-shrink:0; animation:arrow .9s ease-in-out infinite; }
    .src-ref-text { white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    @keyframes refBlink { 0%,100%{opacity:1} 50%{opacity:.65} }
    @keyframes arrow { 0%,100%{transform:translateX(0)} 50%{transform:translateX(-3px)} }

    /* Card spinner */
    .img-spinner {
        position:absolute; top:10px; right:10px;
        width:24px; height:24px;
        border:3px solid rgba(255,255,255,.3);
        border-top-color:white; border-radius:50%;
        animation:spin .7s linear infinite; z-index:10;
    }

    .card-body { padding:14px 16px; flex:1; display:flex; flex-direction:column; }

    .card-top { display:flex; align-items:center; justify-content:space-between; margin-bottom:9px; }
    .src-count {
        display:inline-flex; align-items:center; gap:4px;
        padding:3px 8px;
        background:var(--purple-light); color:var(--purple-md);
        border-radius:99px; font-size:10px; font-weight:600;
        font-family:'Fira Code',monospace;
    }
    .src-count .material-icons-round { font-size:11px!important; }

    .card-time {
        font-size:10px; color:var(--ink-faint);
        font-family:'Fira Code',monospace;
        display:flex; align-items:center; gap:3px;
    }
    .card-time .material-icons-round { font-size:11px!important; }

    .card-title {
        font-family:'Playfair Display',serif;
        font-size:15px; line-height:1.45; color:var(--ink);
        display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden;
        margin-bottom:8px;
        transition:color .15s;
    }
    .news-card:hover .card-title { color:var(--purple); }

    .card-foot {
        margin-top:auto; padding-top:10px;
        border-top:1px solid var(--border);
        display:flex; align-items:center; gap:6px;
        font-size:11px; color:var(--ink-faint);
    }
    .card-foot .material-icons-round { font-size:12px!important; }
    .src-dot { width:7px; height:7px; border-radius:50%; background:var(--purple); flex-shrink:0; }

    /* ═══ Empty / Error ══════════════════════════════════════════════ */
    .empty-state {
        grid-column: 1/-1;
        background:var(--surface); border:1px solid var(--border);
        border-radius:var(--r); padding:60px 24px;
        text-align:center; box-shadow:var(--sh);
    }
    .empty-icon {
        width:64px; height:64px; border-radius:50%;
        background:var(--purple-light);
        display:flex; align-items:center; justify-content:center;
        margin:0 auto 16px;
    }
    .empty-icon .material-icons-round { font-size:30px!important; color:var(--purple); }
    .empty-state h3 { font-family:'Playfair Display',serif; font-size:22px; margin-bottom:8px; }
    .empty-state p { font-size:13px; color:var(--ink-muted); max-width:320px; margin:0 auto 18px; }

    /* ═══ Success Banner ════════════════════════════════════════════ */
    .success-banner {
        background:linear-gradient(135deg,#10B981,#059669);
        color:white; border-radius:var(--r); padding:20px 22px;
        position:relative; box-shadow:0 4px 14px rgba(16,185,129,.3);
        margin-bottom:20px;
    }
    .success-banner .material-icons-round { font-size:36px!important; margin-bottom:8px; }
    .success-banner h3 { font-family:'Playfair Display',serif; font-size:18px; margin-bottom:4px; }
    .success-banner p { font-size:13px; opacity:.9; line-height:1.5; }
    .success-banner .close-x {
        position:absolute; top:12px; right:12px;
        width:28px; height:28px; border-radius:50%;
        background:rgba(255,255,255,.2); border:none; cursor:pointer;
        color:white; display:flex; align-items:center; justify-content:center;
        transition:background .15s;
    }
    .success-banner .close-x:hover { background:rgba(255,255,255,.35); }
    .success-banner .close-x .material-icons-round { font-size:16px!important; }

    /* ═══ Modal ══════════════════════════════════════════════════════ */
    .modal-bg {
        display:none; position:fixed; inset:0;
        background:rgba(0,0,0,.7);
        backdrop-filter:blur(6px);
        z-index:200;
        align-items:center; justify-content:center;
        padding:24px;
    }
    .modal-bg.open { display:flex; animation:fadeBg .2s ease; }
    @keyframes fadeBg { from{opacity:0} to{opacity:1} }

    .modal-box {
        background:var(--surface);
        border-radius:16px;
        width:100%; max-width:780px; max-height:90vh;
        overflow:hidden; display:flex; flex-direction:column;
        box-shadow:0 24px 80px rgba(0,0,0,.35);
        animation:modalIn .25s cubic-bezier(.4,0,.2,1);
    }
    @keyframes modalIn {
        from{transform:translateY(18px) scale(.98);opacity:0}
        to{transform:none;opacity:1}
    }

    .modal-head {
        padding:18px 24px;
        border-bottom:1px solid var(--border);
        display:flex; align-items:center; justify-content:space-between;
        flex-shrink:0; background:var(--surface);
        position:sticky; top:0; z-index:5;
    }
    .modal-head-title {
        display:flex; align-items:center; gap:8px;
        font-family:'Playfair Display',serif; font-size:17px; color:var(--ink);
    }
    .modal-head-title .material-icons-round { font-size:20px!important; color:var(--purple); }
    .modal-close {
        width:34px; height:34px; border-radius:50%;
        border:1px solid var(--border); background:transparent;
        cursor:pointer; color:var(--ink-faint);
        display:flex; align-items:center; justify-content:center;
        transition:all .15s;
    }
    .modal-close:hover { background:var(--canvas); color:var(--ink); }
    .modal-close .material-icons-round { font-size:17px!important; }

    .modal-scroll { overflow-y:auto; flex:1; }
    .modal-scroll::-webkit-scrollbar { width:5px; }
    .modal-scroll::-webkit-scrollbar-thumb { background:var(--border-md); border-radius:99px; }

    .modal-hero {
        height:260px; position:relative; overflow:hidden;
        background:linear-gradient(135deg, var(--purple-light), var(--surface-2));
        flex-shrink:0;
    }
    .modal-hero img { width:100%; height:100%; object-fit:cover; }
    .modal-hero-ph { width:100%; height:100%; display:flex; align-items:center; justify-content:center; }
    .modal-hero-ph .material-icons-round { font-size:64px!important; color:var(--border-md); }
    .modal-hero-veil {
        position:absolute; inset:0;
        background:linear-gradient(to bottom,transparent 40%,rgba(0,0,0,.55));
        pointer-events:none;
    }

    .modal-body { padding:22px 26px; }

    .modal-tags { display:flex; gap:7px; margin-bottom:12px; flex-wrap:wrap; }
    .modal-tag {
        display:inline-flex; align-items:center; gap:4px;
        padding:5px 11px; border-radius:6px;
        font-size:11px; font-weight:700;
        text-transform:uppercase; letter-spacing:.06em;
    }
    .modal-tag.hot     { background:rgba(239,68,68,.12); color:#DC2626; border:1px solid rgba(239,68,68,.25); }
    .modal-tag.sources { background:var(--purple-light); color:var(--purple-md); border:1px solid var(--info-bd); }
    .modal-tag.live    { background:#FEF3C7; color:#92400E; border:1px solid #FDE68A; }
    .modal-tag .material-icons-round { font-size:12px!important; }

    .modal-title {
        font-family:'Playfair Display',serif;
        font-size:22px; line-height:1.4; color:var(--ink); margin-bottom:12px;
    }
    .modal-meta-row {
        font-size:13px; color:var(--ink-muted); line-height:1.9; margin-bottom:16px;
    }
    .modal-meta-row strong { color:var(--ink); }
    .modal-src-link {
        display:inline-flex; align-items:center; gap:4px;
        padding:3px 9px;
        background:var(--purple-light); color:var(--purple-md);
        border-radius:6px; font-weight:600; font-size:12px;
        text-decoration:none; transition:all .15s; margin:2px 2px;
    }
    .modal-src-link:hover { background:var(--info-bd); transform:translateY(-1px); box-shadow:0 2px 8px var(--purple-glow); }
    .modal-src-link .material-icons-round { font-size:12px!important; }

    .modal-acts { display:flex; gap:9px; flex-wrap:wrap; padding-top:14px; border-top:1px solid var(--border); }

    /* Developing section */
    .dev-section { margin-top:22px; }
    .dev-header {
        display:flex; align-items:center; justify-content:space-between;
        padding-bottom:14px; border-bottom:1px solid var(--border);
        margin-bottom:16px; flex-wrap:wrap; gap:10px;
    }
    .dev-header-left { display:flex; align-items:center; gap:10px; }
    .dev-title { font-family:'Playfair Display',serif; font-size:17px; color:var(--ink); }
    .dev-badge {
        padding:4px 10px; border-radius:6px;
        background:#FEE2E2; color:#991B1B;
        font-size:10px; font-weight:700;
        text-transform:uppercase; letter-spacing:.08em;
        animation:devBlink 2s ease-in-out infinite;
    }
    @keyframes devBlink { 0%,100%{opacity:1} 50%{opacity:.6} }

    .dev-toggle {
        display:flex; align-items:center; gap:7px;
        font-size:12px; font-weight:500; color:var(--ink-muted);
        cursor:pointer;
    }
    .dev-toggle input[type=checkbox] {
        width:15px; height:15px; cursor:pointer;
        accent-color:var(--purple);
    }

    .dev-loading { text-align:center; padding:36px; color:var(--ink-faint); }
    .dev-loading .loading-ring { width:36px; height:36px; margin:0 auto 12px; }
    .dev-loading p { font-size:13px; }

    .related-list { display:flex; flex-direction:column; gap:10px; }
    .related-item {
        background:var(--canvas);
        border:1px solid var(--border);
        border-left:3px solid var(--purple);
        border-radius:var(--r-sm);
        padding:14px 16px;
        transition:box-shadow .15s;
    }
    .related-item:hover { box-shadow:var(--sh-md); }
    .related-item-title {
        font-family:'Playfair Display',serif;
        font-size:14px; line-height:1.4; color:var(--ink);
        margin-bottom:8px;
    }
    .related-meta { display:flex; gap:12px; flex-wrap:wrap; margin-bottom:10px; }
    .related-meta-item {
        display:flex; align-items:center; gap:4px;
        font-size:11px; color:var(--ink-faint);
        font-family:'Fira Code',monospace;
    }
    .related-meta-item .material-icons-round { font-size:12px!important; }
    .related-src-link {
        display:inline-flex; align-items:center; gap:4px;
        padding:2px 8px;
        background:var(--purple-light); color:var(--purple-md);
        border-radius:5px; font-weight:600; font-size:11px;
        text-decoration:none; transition:all .15s;
    }
    .related-src-link:hover { background:var(--info-bd); }
    .related-acts { display:flex; gap:7px; flex-wrap:wrap; }

    .no-related { text-align:center; padding:36px; color:var(--ink-faint); font-size:13px; }

    /* ═══ Buttons ═══════════════════════════════════════════════════ */
    .btn {
        display:inline-flex; align-items:center; gap:6px;
        padding:9px 16px;
        border-radius:var(--r-sm);
        font-family:'Sora',sans-serif;
        font-size:13px; font-weight:500;
        cursor:pointer; border:none;
        transition:all .15s; text-decoration:none; white-space:nowrap;
    }
    .btn .material-icons-round { font-size:15px!important; }
    .btn-purple { background:var(--purple); color:white; }
    .btn-purple:hover { background:var(--purple-md); box-shadow:0 4px 12px var(--purple-glow); }
    .btn-outline { background:var(--surface); border:1px solid var(--border); color:var(--ink); }
    .btn-outline:hover { background:var(--canvas); border-color:var(--border-md); }
    .btn-green { background:#10B981; color:white; }
    .btn-green:hover { background:#059669; box-shadow:0 4px 12px rgba(16,185,129,.35); }
    .btn-ghost { background:transparent; color:var(--ink-faint); }
    .btn-ghost:hover { background:var(--canvas); color:var(--ink); }
    .btn-sm { padding:6px 12px; font-size:12px; }

    /* ═══ Toasts ════════════════════════════════════════════════════ */
    .toast-stack {
        position:fixed; top:68px; right:14px;
        z-index:999; display:flex; flex-direction:column; gap:6px;
        pointer-events:none;
    }
    .toast {
        display:flex; align-items:center; gap:9px;
        padding:11px 14px;
        border-radius:var(--r-sm);
        font-family:'Sora',sans-serif;
        font-size:12px; font-weight:500;
        min-width:250px; max-width:360px;
        box-shadow:var(--sh-lg);
        pointer-events:all;
        animation:toastIn .22s ease;
        border:1px solid;
    }
    @keyframes toastIn { from{transform:translateX(12px);opacity:0} to{transform:none;opacity:1} }
    .toast.success { background:var(--success-bg); color:var(--success-text); border-color:var(--success-bd); }
    .toast.error   { background:var(--error-bg);   color:var(--error-text);   border-color:var(--error-bd);   }
    .toast.warning { background:var(--warn-bg);     color:var(--warn-text);    border-color:var(--warn-bd);    }
    .toast.info    { background:var(--info-bg);     color:var(--info-text);    border-color:var(--info-bd);    }
    .toast .material-icons-round { font-size:15px!important; flex-shrink:0; }
    .toast-msg { flex:1; }
    .toast-x { cursor:pointer; opacity:.6; line-height:1; }
    .toast-x:hover { opacity:1; }

    /* ═══ Responsive ════════════════════════════════════════════════ */
    @media (max-width:768px) {
        .news-grid { grid-template-columns:1fr; }
        .topbar-search { max-width:200px; }
        .brand-sub { display:none; }
        .page-wrap { padding:16px; }
        .modal-box { max-height:95vh; }
    }
    @media (max-width:480px) {
        .topbar { padding:0 14px; gap:8px; }
        .filter-inner { padding:8px 14px; }
        .stats-inner { padding:7px 14px; }
        .tb-btn span:not(.material-icons-round) { display:none; }
        .tb-btn-icon span { display:flex!important; }
    }
    </style>
</head>
<body>

<!-- ═══════════════════════════════════════ TOP COMMAND BAR ══ -->
<header class="topbar">
    <a class="brand" href="#">
        <div class="brand-mark"><span class="material-icons-round">newspaper</span></div>
        <div>
            <span class="brand-name">LiveFeed PH</span>
            <span class="brand-sub">Philippines · <span id="currentDate">—</span></span>
        </div>
    </a>

    <div class="topbar-search">
        <span class="material-icons-round s-icon">search</span>
        <input type="text" id="searchInput" placeholder="Search today's news…" autocomplete="off"/>
    </div>

    <div class="live-pill">
        <span class="live-dot"></span>
        Live Feed
    </div>

    <div class="topbar-right">
        <button class="tb-btn tb-btn-ghost" onclick="importAllNews()">
            <span class="material-icons-round">cloud_download</span>
            <span>Import All (<span id="importCount">0</span>)</span>
        </button>
        <button class="tb-btn tb-btn-ghost tb-btn-icon" onclick="loadTestData()" title="Load test data">
            <span class="material-icons-round">science</span>
        </button>
        <button class="tb-btn tb-btn-purple" onclick="showDashboard()">
            <span class="material-icons-round">dashboard</span>
            <span>Dashboard</span>
        </button>
        <button class="tb-btn tb-btn-ghost tb-btn-icon" onclick="refreshNews()" title="Refresh feed">
            <span class="material-icons-round">refresh</span>
        </button>
        <button class="tb-btn tb-btn-ghost tb-btn-icon" onclick="toggleDark()" id="darkBtn" title="Toggle dark mode">
            <span class="material-icons-round">dark_mode</span>
        </button>
    </div>
</header>

<!-- ═══════════════════════════════════════ FILTER BAR ══ -->
<div class="filter-bar">
    <div class="filter-inner">
        <!-- Category chips -->
        <button class="cat-chip hot active" onclick="selectPhilippinesTrending(this)">
            <span class="material-icons-round">local_fire_department</span> Philippines Trending
        </button>
        <button class="cat-chip" onclick="selectCategory('business', this)">
            <span class="material-icons-round">trending_up</span> Business
        </button>
        <button class="cat-chip" onclick="selectCategory('entertainment', this)">
            <span class="material-icons-round">movie</span> Entertainment
        </button>
        <button class="cat-chip" onclick="selectCategory('health', this)">
            <span class="material-icons-round">favorite</span> Health
        </button>
        <button class="cat-chip" onclick="selectCategory('politics', this)">
            <span class="material-icons-round">account_balance</span> Politics
        </button>
        <button class="cat-chip" onclick="selectCategory('science', this)">
            <span class="material-icons-round">biotech</span> Science
        </button>
        <button class="cat-chip" onclick="selectCategory('sports', this)">
            <span class="material-icons-round">sports_soccer</span> Sports
        </button>
        <button class="cat-chip" onclick="selectCategory('technology', this)">
            <span class="material-icons-round">memory</span> Technology
        </button>
        <button class="cat-chip" onclick="selectCategory('weather', this)">
            <span class="material-icons-round">partly_cloudy_day</span> Weather
        </button>

        <div class="filter-divider"></div>

        <!-- Location chips -->
        <span style="font-size:11px;color:var(--ink-faint);font-weight:600;letter-spacing:.05em">LOCATION</span>
        <button class="loc-chip disabled" onclick="selectLocation('worldwide', this)">🌐 Worldwide</button>
        <button class="loc-chip active disabled" onclick="selectLocation('Philippines', this)">🇵🇭 Philippines</button>
        <button class="loc-chip disabled" onclick="selectLocation('Luzon Philippines', this)">📍 Luzon</button>
        <button class="loc-chip disabled" onclick="selectLocation('Visayas Philippines', this)">📍 Visayas</button>
        <button class="loc-chip disabled" onclick="selectLocation('Mindanao Philippines', this)">📍 Mindanao</button>
    </div>
</div>

<!-- ═══════════════════════════════════════ STATS STRIP ══ -->
<div class="stats-strip">
    <div class="stats-inner">
        <div class="stats-left">
            <div class="stat-item">
                <span class="material-icons-round">schedule</span>
                Updated <strong id="loadTime">—:—</strong>
            </div>
            <div id="filterBadge" class="filter-badge">
                <span class="material-icons-round" style="font-size:12px!important">local_fire_department</span>
                <span id="filterBadgeText">🔥 Philippines Trending · 🇵🇭 Top Media</span>
            </div>
            <div class="stat-item">
                <span class="material-icons-round">article</span>
                Showing <strong id="newsCount">0</strong> of <strong id="totalNews">0</strong>
            </div>
        </div>
        <div class="per-page-wrap">
            <label>Show</label>
            <select id="perPage" onchange="updatePerPage()">
                <option value="12">12</option>
                <option value="24">24</option>
                <option value="50">50</option>
                <option value="100">100</option>
            </select>
            <label>per page</label>
        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════ MAIN ══ -->
<div class="page-wrap">
    <div id="loading" style="display:none"></div>
    <div id="newsGrid" class="news-grid"></div>
</div>

<!-- ═══════════════════════════════════════ MODAL ══ -->
<div class="modal-bg" id="articleModal" onclick="handleModalBgClick(event)">
    <div class="modal-box">
        <div class="modal-head">
            <div class="modal-head-title">
                <span class="material-icons-round">article</span>
                Article Details
            </div>
            <button class="modal-close" onclick="closeModal()">
                <span class="material-icons-round">close</span>
            </button>
        </div>
        <div class="modal-scroll" id="modalBody"></div>
    </div>
</div>

<!-- Toasts -->
<div class="toast-stack" id="toastStack"></div>

<script>
    /* ════════════════════════════ STATE ══ */
    let currentNews = [];
    let currentCategory = 'Philippines Trending';
    let currentLocation = 'Philippines';
    let displayedCount = 12;
    let currentFetchController = null;
    let fetchTimeout = null;
    let isTrendingActive = true;
    let developingNewsArticles = [];
    let showDevelopingInDashboard = false;
    let currentMainArticle = null;

    /* ════════════════════════════ DARK MODE ══ */
    function toggleDark() {
        const html = document.documentElement;
        const dark = html.dataset.theme === 'dark';
        html.dataset.theme = dark ? 'light' : 'dark';
        localStorage.setItem('theme', dark ? 'light' : 'dark');
        document.getElementById('darkBtn').querySelector('.material-icons-round').textContent =
            dark ? 'dark_mode' : 'light_mode';
    }
    (function(){
        const t = localStorage.getItem('theme') || 'light';
        document.documentElement.dataset.theme = t;
        const btn = document.getElementById('darkBtn');
        if (btn) btn.querySelector('.material-icons-round').textContent = t === 'dark' ? 'light_mode' : 'dark_mode';
    })();

    /* ════════════════════════════ DATE PARSING ══ */
    function parsePubDate(dateStr) {
        if (!dateStr) return new Date();
        const cleaned = String(dateStr)
            .replace(/\s*(GMT|UTC|PHT|PST|EST|CST|[A-Z]{2,5})\s*$/i, '')
            .replace(/Z$/, '').replace(/[+-]\d{2}:?\d{2}\s*$/, '').trim();
        const parsed = new Date(cleaned);
        return isNaN(parsed.getTime()) ? new Date(dateStr) : parsed;
    }

    /* ════════════════════════════ TOAST ══ */
    function showToast(message, type = 'info') {
        const icons = { success:'check_circle', error:'error', warning:'warning', info:'info' };
        const el = document.createElement('div');
        el.className = `toast ${type}`;
        el.innerHTML = `<span class="material-icons-round">${icons[type]||'info'}</span>
            <span class="toast-msg">${message}</span>
            <span class="toast-x material-icons-round" onclick="this.parentElement.remove()">close</span>`;
        document.getElementById('toastStack').appendChild(el);
        setTimeout(() => { el.style.opacity='0'; el.style.transition='opacity .3s'; }, 4500);
        setTimeout(() => el.remove(), 5000);
    }

    /* ════════════════════════════ LOCATION TOGGLE ══ */
    function toggleLocationButtons(disable) {
        document.querySelectorAll('.loc-chip').forEach(btn => {
            disable ? btn.classList.add('disabled') : btn.classList.remove('disabled');
        });
    }

    /* ════════════════════════════ DEVELOPING NEWS DASHBOARD ══ */
    function toggleDevelopingNewsInDashboard() {
        const checkbox = document.getElementById('showDevelopingCheckbox');
        showDevelopingInDashboard = checkbox.checked;
        if (showDevelopingInDashboard) {
            addDevelopingNewsToDashboard();
            showToast(`Added ${developingNewsArticles.length} related articles to dashboard`, 'success');
        } else {
            removeDevelopingNewsFromDashboard();
            showToast('Removed related articles from dashboard', 'info');
        }
    }
    function addDevelopingNewsToDashboard() {
        if (!developingNewsArticles.length) return;
        const marked = developingNewsArticles.map(a => ({...a, isDevelopingNews:true,
            mainArticleTitle: currentMainArticle?.title||'Unknown Article',
            mainArticleIndex: currentMainArticle?.originalIndex??-1 }));
        currentNews = currentNews.filter(a => !a.isDevelopingNews);
        currentNews = [...marked, ...currentNews];
        isTrendingActive ? displayTrendingNews(currentNews.slice(0,displayedCount))
                        : displayNews(currentNews.slice(0,displayedCount));
        updateStats(); setupInstantImageLoading();
    }
    function removeDevelopingNewsFromDashboard() {
        currentNews = currentNews.filter(a => !a.isDevelopingNews);
        isTrendingActive ? displayTrendingNews(currentNews.slice(0,displayedCount))
                        : displayNews(currentNews.slice(0,displayedCount));
        updateStats(); setupInstantImageLoading();
    }

    /* ════════════════════════════ ARTICLE ROUTING ══ */
    function viewArticleByIndex(index) {
        const article = currentNews[index];
        if (article.isDevelopingNews) {
            viewSimpleDevelopingArticle(index);
        } else if (article.relatedArticles && article.relatedArticles.length > 0) {
            viewTrendingArticle(index);
        } else {
            viewArticleWithDevelopingNews(index);
        }
    }

    function viewSimpleDevelopingArticle(index) {
        const article = currentNews[index];
        const modal = document.getElementById('articleModal');
        const modalBody = document.getElementById('modalBody');
        const pubDate = parsePubDate(article.pubDate);
        const formattedDate = pubDate.toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric',hour:'2-digit',minute:'2-digit'});
        const imgEl = document.getElementById(`img-${index}`);
        const imgSrc = imgEl?.querySelector('img')?.src;
        modalBody.innerHTML = buildModalHero(imgSrc, article.title) + `
            <div class="modal-body">
                <div class="modal-tags"><span class="modal-tag sources"><span class="material-icons-round">link</span>Related Article</span></div>
                <h2 class="modal-title">${esc(article.title)}</h2>
                <div class="modal-meta-row">
                    <strong>Source:</strong> ${esc(article.author||'Unknown')}<br>
                    <strong>Published:</strong> ${formattedDate}
                </div>
                <div class="modal-acts">
                    <a href="${esc(article.link)}" target="_blank" class="btn btn-purple">
                        <span class="material-icons-round">open_in_new</span> Read Full Article
                    </a>
                    <button class="btn btn-green" onclick='importSingleArticle(${JSON.stringify(article).replace(/'/g,"&apos;")})'>
                        <span class="material-icons-round">cloud_download</span> Import
                    </button>
                </div>
            </div>`;
        modal.classList.add('open');
    }

    /* ════════════════════════════ SAVE ARTICLE ══ */
    async function saveArticle(article, btnElement) {
        if (!article || !btnElement) { showToast('Invalid article data','error'); return; }
        const originalHTML = btnElement.innerHTML;
        btnElement.disabled = true;
        btnElement.innerHTML = '<span class="material-icons-round" style="animation:spin .8s linear infinite">refresh</span> Fetching…';
        btnElement.style.opacity = '.75';
        let fullContent = article.description || article.title;
        if (article.link && article.link !== '#') {
            try {
                const r = await fetch(`fetch_article.php?url=${encodeURIComponent(article.link)}`,{signal:AbortSignal.timeout(20000)});
                const d = await r.json();
                if (d.success && d.content) fullContent = d.content;
            } catch(e) {}
        }
        btnElement.innerHTML = '<span class="material-icons-round" style="animation:spin .8s linear infinite">refresh</span> Importing…';
        try {
            const r = await fetch('save.php',{method:'POST',headers:{'Content-Type':'application/json'},
                body: JSON.stringify({title:article.title,content:fullContent,category:currentCategory,
                    source:article.author||article.source||'Unknown',author:article.author||article.source||'',
                    published_at:article.pubDate,url:article.link,image:'',description:article.description||''})});
            if (!r.ok) throw new Error(`HTTP ${r.status}`);
            const data = await r.json();
            if (data.success) {
                showToast(data.message||'Article imported successfully!','success');
                btnElement.innerHTML = '<span class="material-icons-round">check_circle</span> Imported';
                btnElement.style.background = '#059669'; btnElement.style.color = 'white';
                btnElement.style.opacity = '1'; btnElement.disabled = true;
            } else {
                const isEx = (data.message||'').includes('already exists');
                showToast(data.message, isEx ? 'warning' : 'error');
                if (isEx) {
                    btnElement.innerHTML = '<span class="material-icons-round">info</span> Already Imported';
                    btnElement.style.background = '#F59E0B'; btnElement.style.color='white'; btnElement.disabled=true;
                } else {
                    btnElement.disabled=false; btnElement.innerHTML=originalHTML; btnElement.style.opacity='1';
                }
            }
        } catch(e) {
            showToast('Failed to import: '+e.message,'error');
            btnElement.disabled=false; btnElement.innerHTML=originalHTML; btnElement.style.opacity='1';
        }
    }

    async function saveAllVisibleArticles() {
        const all = currentNews.slice(0,displayedCount);
        if (!all.length) { showToast('No articles to import','warning'); return; }
        if (!confirm(`Import all ${all.length} visible articles?\nThis will fetch full content for each and may take a moment.`)) return;
        let saved=0, failed=0, exists=0;
        showToast(`Starting import of ${all.length} articles…`,'info');
        document.querySelectorAll('.import-btn-card,.related-import-btn').forEach(b=>{b.disabled=true;b.style.opacity='.5';});
        for (let i=0;i<all.length;i++){
            const article=all[i];
            let fullContent = article.description||article.title;
            if (article.link&&article.link!=='#'){
                try {
                    const r=await fetch(`fetch_article.php?url=${encodeURIComponent(article.link)}`,{signal:AbortSignal.timeout(20000)});
                    const d=await r.json();
                    if(d.success&&d.content) fullContent=d.content;
                } catch(e){}
            }
            try {
                const r=await fetch('save.php',{method:'POST',headers:{'Content-Type':'application/json'},
                    body:JSON.stringify({title:article.title,content:fullContent,category:currentCategory,
                        source:article.author||article.source||'Unknown',author:article.author||article.source||'',
                        published_at:article.pubDate,url:article.link,description:article.description||''})});
                const d=await r.json();
                if(d.success) saved++;
                else if((d.message||'').includes('already exists')) exists++;
                else failed++;
            } catch(e){ failed++; }
            showToast(`Importing… ${i+1}/${all.length}`,'info');
        }
        let msg='';
        if(saved) msg+=`✓ ${saved} imported`;
        if(exists) msg+=`${msg?', ':''}${exists} already existed`;
        if(failed) msg+=`${msg?', ':''}${failed} failed`;
        showToast(msg, failed===0?'success':(saved>0?'warning':'error'));
        document.querySelectorAll('.import-btn-card,.related-import-btn').forEach(b=>{
            if(!b.innerHTML.includes('Imported')&&!b.innerHTML.includes('Already')){ b.disabled=false; b.style.opacity='1'; }
        });
    }

    /* ════════════════════════════ STATS ══ */
    function updateStats() {
        const now = new Date();
        document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'});
        document.getElementById('loadTime').textContent = now.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'});
        const actual = Math.min(displayedCount, currentNews.length);
        document.getElementById('newsCount').textContent = actual;
        document.getElementById('totalNews').textContent = currentNews.length;
        document.getElementById('importCount').textContent = actual;
        updatePaginationOptions(currentNews.length);
    }
    function updatePaginationOptions(total) {
        const sel = document.getElementById('perPage');
        sel.innerHTML = '';
        [12,24,50,100].forEach(v => {
            if (v<=total||v===12){
                const o=document.createElement('option');
                o.value=v; o.textContent=v; if(v===displayedCount) o.selected=true;
                sel.appendChild(o);
            }
        });
        if (total>12){
            const o=document.createElement('option');
            o.value=total; o.textContent=`All (${total})`;
            if(displayedCount>=total) o.selected=true;
            sel.appendChild(o);
        }
        if(displayedCount>total) displayedCount=total;
    }
    function updatePerPage() {
        displayedCount = parseInt(document.getElementById('perPage').value);
        isTrendingActive ? displayTrendingNews(currentNews.slice(0,displayedCount))
                         : displayNews(currentNews.slice(0,displayedCount));
        updateStats();
    }

    /* ════════════════════════════ FILTER BADGE ══ */
    function setFilterBadge(html) {
        document.getElementById('filterBadgeText').innerHTML = html;
    }

    /* ════════════════════════════ LOCATION ══ */
    function selectLocation(location, button) {
        if (isTrendingActive || button.classList.contains('disabled')) return;
        document.querySelectorAll('.loc-chip').forEach(b=>b.classList.remove('active'));
        button.classList.add('active');
        currentLocation = location;
        const locText = button.textContent.trim();
        const catBtn = document.querySelector('.cat-chip.active');
        const catText = catBtn ? catBtn.textContent.trim() : 'General';
        setFilterBadge(`${catText} · ${locText}`);
        if (currentFetchController) currentFetchController.abort();
        fetchNews(buildQuery());
    }
    function buildQuery() {
        const kw = {politics:'politics government',weather:'weather typhoon storm',technology:'technology tech',
            business:'business economy',sports:'sports',entertainment:'entertainment',science:'science',
            health:'health medical','world news':'world news','latest news':'news'};
        let q = kw[currentCategory.toLowerCase()] || currentCategory;
        if (currentLocation==='worldwide') {}
        else if (currentLocation==='Philippines') q=`Philippines ${q}`;
        else { let r=currentLocation.replace(' Philippines',''); q=`${r} Philippines ${q}`; }
        return q;
    }
    function selectCategory(category, button) {
        isTrendingActive = false;
        toggleLocationButtons(false);
        document.querySelectorAll('.cat-chip').forEach(b=>b.classList.remove('active'));
        button.classList.add('active');
        currentCategory = category;
        document.getElementById('searchInput').value = '';
        const locBtn = document.querySelector('.loc-chip.active');
        const locText = locBtn ? locBtn.textContent.trim() : '🇵🇭 Philippines';
        setFilterBadge(`${button.textContent.trim()} · ${locText}`);
        if (currentFetchController) currentFetchController.abort();
        fetchNews(buildQuery());
    }

    /* ════════════════════════════ TRENDING ══ */
    async function selectPhilippinesTrending(button) {
        isTrendingActive = true;
        toggleLocationButtons(true);
        document.querySelectorAll('.cat-chip').forEach(b=>b.classList.remove('active'));
        button.classList.add('active');
        currentCategory = 'Philippines Trending';
        setFilterBadge('🔥 Philippines Trending · 🇵🇭 Top Media');
        showLoadingState('Analyzing trending news from GMA, Inquirer, Philstar, Rappler…');
        try {
            const r = await fetch('trending_philippines.php');
            const data = await r.json();
            if (data.success && data.trendingTopics.length>0) {
                currentNews = data.trendingTopics;
                displayTrendingNews(currentNews.slice(0,displayedCount));
                hideLoading(); updateStats();
                showToast(`Found ${data.trendingTopics.length} trending topics from ${data.totalArticles} articles`,'success');
            } else throw new Error(data.message||'No trending topics found');
        } catch(e) {
            showErrorState('Failed to load trending news', e.message);
            showToast('Failed to load trending news: '+e.message,'error');
        }
    }

    /* ════════════════════════════ DISPLAY TRENDING ══ */
    function displayTrendingNews(articles) {
        const grid = document.getElementById('newsGrid');
        grid.innerHTML = '';
        articles.forEach((article, index) => {
            const card = buildCard(article, index, true);
            grid.appendChild(card);
        });
        setupInstantImageLoading();
    }

    /* ════════════════════════════ DISPLAY REGULAR ══ */
    async function displayNews(articles) {
        const grid = document.getElementById('newsGrid');
        grid.innerHTML = '';
        articles.forEach((article, index) => {
            const card = buildCard(article, index, false);
            grid.appendChild(card);
        });
        setupInstantImageLoading();
    }

    /* ════════════════════════════ CARD BUILDER ══ */
    function buildCard(article, index, isTrending) {
        const card = document.createElement('div');
        card.className = 'news-card';
        card.onclick = () => viewArticleByIndex(index);

        const pubDate = parsePubDate(article.pubDate);
        const ago = timeAgoJS(article.pubDate);
        const ph = createGradientPlaceholder(currentCategory);

        // Badge(s)
        let badgeHTML = '<div class="badge-overlay">';
        if (article.isDevelopingNews) {
            badgeHTML += `<span class="ov-badge related"><span class="material-icons-round">link</span>Related</span>`;
        } else if (isTrending) {
            if ((article.sourceCount||0)>=4) {
                badgeHTML += `<span class="ov-badge hot"><span class="material-icons-round">local_fire_department</span>Hot</span>`;
            } else if ((article.sourceCount||0)>=3) {
                badgeHTML += `<span class="ov-badge trending"><span class="material-icons-round">trending_up</span>Trending</span>`;
            } else {
                badgeHTML += `<span class="ov-badge" style="background:rgba(59,130,246,.9);color:white"><span class="material-icons-round">arrow_upward</span>Rising</span>`;
            }
        }
        badgeHTML += '</div>';

        let srcRefHTML = '';
        if (article.isDevelopingNews && article.mainArticleTitle) {
            const trunc = article.mainArticleTitle.length>42 ? article.mainArticleTitle.substring(0,42)+'…' : article.mainArticleTitle;
            srcRefHTML = `<div class="src-ref-banner"><span class="material-icons-round">arrow_back</span><span class="src-ref-text">From: ${esc(trunc)}</span></div>`;
        }

        const srcCount = isTrending && article.sourceCount
            ? `<span class="src-count"><span class="material-icons-round">source</span>${article.sourceCount} sources</span>`
            : '';
        const srcName = esc(article.sources||article.author||'Unknown');

        card.innerHTML = `
            <div class="card-img-wrap" id="img-${index}" style="background:${ph.gradient}" data-index="${index}">
                ${badgeHTML}
                ${srcRefHTML}
                <div class="img-placeholder"><span class="material-icons-round">${ph.iconMI}</span></div>
                <div class="img-veil"></div>
                <div class="img-spinner"></div>
            </div>
            <div class="card-body">
                <div class="card-top">
                    ${srcCount}
                    <span class="card-time"><span class="material-icons-round">schedule</span>${ago}</span>
                </div>
                <div class="card-title">${esc(article.title)}</div>
                <div class="card-foot">
                    <div class="src-dot"></div>
                    <span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${srcName}</span>
                </div>
            </div>`;
        return card;
    }

    /* ════════════════════════════ TRENDING ARTICLE VIEW ══ */
    function viewTrendingArticle(index) {
        const article = currentNews[index];
        const modal = document.getElementById('articleModal');
        const modalBody = document.getElementById('modalBody');
        currentMainArticle = {title:article.title,originalIndex:index,link:article.link,author:article.sources||article.author};
        const formattedDate = parsePubDate(article.pubDate).toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric',hour:'2-digit',minute:'2-digit'});
        const imgEl = document.getElementById(`img-${index}`);
        const imgSrc = imgEl?.querySelector('img')?.src;
        developingNewsArticles = article.relatedArticles||[];
        // Unique sources
        const uniq=[]; const seen=new Set();
        (article.relatedArticles||[]).forEach(r=>{
            const k=(r.source||'').toLowerCase().trim();
            if(!seen.has(k)){seen.add(k);uniq.push({name:r.source,link:r.link});}
        });
        const srcLinks = uniq.map(s=>`<a href="${esc(s.link)}" target="_blank" class="modal-src-link" onclick="event.stopPropagation()"><span class="material-icons-round">newspaper</span>${esc(s.name)}</a>`).join(' ');

        modalBody.innerHTML = buildModalHero(imgSrc, article.title) + `
            <div class="modal-body">
                <div class="modal-tags">
                    <span class="modal-tag hot"><span class="material-icons-round">local_fire_department</span>Trending</span>
                    <span class="modal-tag sources"><span class="material-icons-round">source</span>${article.sourceCount} media outlets</span>
                </div>
                <h2 class="modal-title">${esc(article.title)}</h2>
                <div class="modal-meta-row">
                    <strong>Sources:</strong> ${srcLinks}<br>
                    <strong>Published:</strong> ${formattedDate}
                </div>
                <div class="modal-acts">
                    <button class="btn btn-green" onclick='importSingleArticle(${JSON.stringify(article).replace(/'/g,"&apos;")})'>
                        <span class="material-icons-round">cloud_download</span> Import Article
                    </button>
                </div>
            </div>
            ${buildDevSection(article.relatedArticles||[], article.sourceCount)}`;
        modal.classList.add('open');
        if (showDevelopingInDashboard) addDevelopingNewsToDashboard();
    }

    /* ════════════════════════════ REGULAR ARTICLE VIEW ══ */
    async function viewArticleWithDevelopingNews(index) {
        const article = currentNews[index];
        const modal = document.getElementById('articleModal');
        const modalBody = document.getElementById('modalBody');
        currentMainArticle = {title:article.title,originalIndex:index,link:article.link,author:article.author};
        const formattedDate = parsePubDate(article.pubDate).toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric',hour:'2-digit',minute:'2-digit'});
        const imgEl = document.getElementById(`img-${index}`);
        const imgSrc = imgEl?.querySelector('img')?.src;

        modalBody.innerHTML = buildModalHero(imgSrc, article.title) + `
            <div class="modal-body">
                <h2 class="modal-title">${esc(article.title)}</h2>
                <div class="modal-meta-row">
                    <strong>Source:</strong> ${esc(article.author||'Unknown')}<br>
                    <strong>Published:</strong> ${formattedDate}
                </div>
                <div class="modal-acts">
                    <a href="${esc(article.link)}" target="_blank" class="btn btn-purple">
                        <span class="material-icons-round">open_in_new</span> Read
                    </a>
                    <button class="btn btn-green" onclick='importSingleArticle(${JSON.stringify(article).replace(/'/g,"&apos;")})'>
                        <span class="material-icons-round">cloud_download</span> Import
                    </button>
                </div>
            </div>
            <div class="dev-section" style="padding:0 26px 22px">
                <div class="dev-header">
                    <div class="dev-header-left">
                        <span class="dev-title">🔴 Developing News</span>
                        <span class="dev-badge">Live</span>
                    </div>
                    <label class="dev-toggle">
                        <input type="checkbox" id="showDevelopingCheckbox" onchange="toggleDevelopingNewsInDashboard()" ${showDevelopingInDashboard?'checked':''}>
                        Show in Dashboard
                    </label>
                </div>
                <div class="dev-loading" id="devLoadingState">
                    <div class="loading-ring"></div><p>Loading related articles…</p>
                </div>
            </div>`;
        modal.classList.add('open');

        const related = await fetchDevelopingNews(article);
        developingNewsArticles = related;
        const devSection = modalBody.querySelector('.dev-section');
        devSection.innerHTML = `
            <div class="dev-header">
                <div class="dev-header-left">
                    <span class="dev-title">🔴 Developing News</span>
                    <span class="dev-badge">Live</span>
                </div>
                <label class="dev-toggle">
                    <input type="checkbox" id="showDevelopingCheckbox" onchange="toggleDevelopingNewsInDashboard()" ${showDevelopingInDashboard?'checked':''}>
                    Show in Dashboard
                </label>
            </div>
            ${buildRelatedList(related)}`;
        if (showDevelopingInDashboard) addDevelopingNewsToDashboard();
    }

    /* ════════════════════════════ MODAL HELPERS ══ */
    function buildModalHero(imgSrc, title) {
        return `<div class="modal-hero">
            ${imgSrc ? `<img src="${esc(imgSrc)}" alt="${esc(title||'')}">` : '<div class="modal-hero-ph"><span class="material-icons-round">newspaper</span></div>'}
            <div class="modal-hero-veil"></div>
        </div>`;
    }

    function buildDevSection(relatedArticles, sourceCount) {
        return `<div class="dev-section" style="padding:0 26px 22px">
            <div class="dev-header">
                <div class="dev-header-left">
                    <span class="dev-title">📰 Coverage from Different Sources</span>
                    <span class="dev-badge">${sourceCount} Sources</span>
                </div>
                <label class="dev-toggle">
                    <input type="checkbox" id="showDevelopingCheckbox" onchange="toggleDevelopingNewsInDashboard()" ${showDevelopingInDashboard?'checked':''}>
                    Show in Dashboard
                </label>
            </div>
            ${buildRelatedList(relatedArticles, true)}
        </div>`;
    }

    function buildRelatedList(articles, isTrending=false) {
        if (!articles||!articles.length) return `<div class="no-related"><span class="material-icons-round" style="font-size:30px!important;margin-bottom:8px;display:block;color:var(--border-md)">article</span>No related articles found at this time.</div>`;
        return `<div class="related-list">${articles.map(r=>{
            const d = parsePubDate(r.pubDate);
            const ds = d.toLocaleDateString('en-US',{month:'short',day:'numeric'});
            const ts = d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'});
            const srcName = r.source||r.author||'Unknown';
            const srcLink = r.link;
            const srcLinkHTML = `<a href="${esc(srcLink)}" target="_blank" class="related-src-link" onclick="event.stopPropagation()"><span class="material-icons-round">newspaper</span>${esc(srcName)}</a>`;
            return `<div class="related-item">
                <div class="related-item-title">${esc(r.title)}</div>
                <div class="related-meta">
                    <span class="related-meta-item">${srcLinkHTML}</span>
                    <span class="related-meta-item"><span class="material-icons-round">calendar_today</span>${ds}</span>
                    <span class="related-meta-item"><span class="material-icons-round">schedule</span>${ts}</span>
                </div>
                <div class="related-acts">
                    <button class="btn btn-purple btn-sm related-import-btn"
                        data-title="${(r.title||'').replace(/"/g,'&quot;').replace(/'/g,'&#39;')}"
                        data-link="${esc(r.link)}"
                        data-author="${esc(srcName)}"
                        data-pubdate="${esc(r.pubDate)}"
                        onclick="event.stopPropagation(); importFromButton(this)">
                        <span class="material-icons-round">cloud_download</span> Import
                    </button>
                    <a href="${esc(r.link)}" target="_blank" class="btn btn-outline btn-sm" onclick="event.stopPropagation()">
                        <span class="material-icons-round">open_in_new</span> Read
                    </a>
                </div>
            </div>`;
        }).join('')}</div>`;
    }

    /* ════════════════════════════ MODAL CLOSE ══ */
    function closeModal() { document.getElementById('articleModal').classList.remove('open'); }
    function handleModalBgClick(e) { if(e.target===document.getElementById('articleModal')) closeModal(); }
    document.addEventListener('keydown', e=>{ if(e.key==='Escape') closeModal(); });

    /* ════════════════════════════ FETCH NEWS ══ */
    async function fetchNews(query='latest news') {
        if (currentFetchController) currentFetchController.abort();
        if (fetchTimeout) clearTimeout(fetchTimeout);
        showLoadingState('Loading fresh news…');
        currentFetchController = new AbortController();
        const signal = currentFetchController.signal;
        try {
            fetchTimeout = setTimeout(()=>{ if(!signal.aborted) currentFetchController.abort(); }, 15000);
            const r = await fetch(`rss_proxy_v3.php?q=${encodeURIComponent(query)}`,{signal,headers:{'Accept':'application/xml,text/xml,*/*'}});
            clearTimeout(fetchTimeout);
            if (!r.ok) throw new Error(`HTTP ${r.status}`);
            const xml = await r.text();
            const articles = parseXMLFeed(xml);
            if (articles.length>0){
                currentNews = articles.sort((a,b)=>parsePubDate(b.pubDate)-parsePubDate(a.pubDate));
                displayNews(currentNews.slice(0,displayedCount));
                hideLoading(); updateStats();
            } else throw new Error('No articles found');
        } catch(e){
            if (e.name==='AbortError') return;
            showLoadingState('RSS feed unavailable — loading sample data…', true);
            setTimeout(()=>loadTestData(), 900);
        }
    }

    function parseXMLFeed(xmlString) {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(xmlString,'text/xml');
        if (xmlDoc.querySelector('parsererror')) throw new Error('Invalid XML');
        const items = xmlDoc.querySelectorAll('item');
        const articles=[];
        items.forEach(item=>{
            let title = item.querySelector('title')?.textContent||'';
            let link  = item.querySelector('link')?.textContent||'#';
            const pubDate     = item.querySelector('pubDate')?.textContent||'';
            const description = item.querySelector('description')?.textContent||'';
            if (!title||!link) return;
            let source='Unknown';
            const ld = title.lastIndexOf(' - ');
            if (ld>0){ source=title.substring(ld+3).trim(); title=title.substring(0,ld).trim(); }
            articles.push({title,link,pubDate,author:source,description});
        });
        return articles;
    }

    /* ════════════════════════════ IMAGE LOADING ══ */
    function createGradientPlaceholder(category) {
        const grads = {
            technology:'linear-gradient(135deg,#7C3AED,#5B21B6)',
            business:'linear-gradient(135deg,#6D28D9,#4C1D95)',
            sports:'linear-gradient(135deg,#8B5CF6,#7C3AED)',
            entertainment:'linear-gradient(135deg,#9333EA,#7E22CE)',
            science:'linear-gradient(135deg,#6D28D9,#5B21B6)',
            health:'linear-gradient(135deg,#7C3AED,#6D28D9)',
            politics:'linear-gradient(135deg,#4C1D95,#3B0764)',
            weather:'linear-gradient(135deg,#8B5CF6,#6D28D9)',
        };
        const icons = {
            technology:'memory',business:'trending_up',sports:'sports_soccer',
            entertainment:'movie',science:'biotech',health:'favorite',
            politics:'account_balance',weather:'partly_cloudy_day',
        };
        const cat = currentCategory.toLowerCase().replace(' trending','').trim();
        return {
            gradient: grads[cat]||'linear-gradient(135deg,#7C3AED,#4C1D95)',
            iconMI: icons[cat]||'newspaper'
        };
    }

    function setupInstantImageLoading() {
        const containers = document.querySelectorAll('.card-img-wrap');
        containers.forEach(c=>{
            const idx = parseInt(c.dataset.index);
            loadImageForArticle(idx);
        });
    }

    async function loadImageForArticle(index) {
        const article = currentNews[index];
        const imgContainer = document.getElementById(`img-${index}`);
        const spinner = imgContainer?.querySelector('.img-spinner');
        const ph = createGradientPlaceholder(currentCategory);
        if (!imgContainer||!article) return;

        try {
            let imageUrl = null;
            if (article.imageUrl&&article.imageUrl.trim()) {
                imageUrl = article.imageUrl;
            } else if (currentCategory==='Philippines Trending') {
                try {
                    const q=`${article.title} ${article.source||''} Philippines`;
                    const ctrl=new AbortController();
                    const tid=setTimeout(()=>ctrl.abort(),5000);
                    const r=await fetch(`rss_images.php?action=get-rss-images&query=${encodeURIComponent(q)}&limit=3`,{signal:ctrl.signal});
                    clearTimeout(tid);
                    if(r.ok){
                        const d=await r.json();
                        if(d.success&&d.articles?.length) for(const a of d.articles){if(a.imageUrl){imageUrl=a.imageUrl;break;}}
                    }
                } catch(e){}
            }
            if (!imageUrl) {
                const q=article.source?`${article.title} ${article.source} Philippines news`:article.title;
                try {
                    const ctrl=new AbortController();
                    const tid=setTimeout(()=>ctrl.abort(),5000);
                    const r=await fetch(`image_search.php?action=search-image&title=${encodeURIComponent(q)}`,{signal:ctrl.signal});
                    clearTimeout(tid);
                    if(r.ok){const d=await r.json();if(d.success&&d.imageUrl) imageUrl=d.imageUrl;}
                } catch(e){}
            }
            if (spinner) spinner.remove();
            if (imageUrl) {
                const img = document.createElement('img');
                img.src = imageUrl;
                img.onerror=()=>{
                    if(imgContainer) setPlaceholderContent(imgContainer, ph);
                };
                img.onload=()=>{ if(imgContainer) imgContainer.classList.add('has-image'); };
                if (imgContainer) {
                    const devBadge=imgContainer.querySelector('.badge-overlay');
                    const srcRef=imgContainer.querySelector('.src-ref-banner');
                    const veil=imgContainer.querySelector('.img-veil');
                    imgContainer.innerHTML='';
                    if(devBadge) imgContainer.appendChild(devBadge.cloneNode(true));
                    if(srcRef)  imgContainer.appendChild(srcRef.cloneNode(true));
                    imgContainer.appendChild(img);
                    const v=document.createElement('div'); v.className='img-veil'; imgContainer.appendChild(v);
                }
            } else {
                if(imgContainer) setPlaceholderContent(imgContainer, ph);
            }
        } catch(e) {
            if(spinner) spinner.remove();
            if(imgContainer) setPlaceholderContent(imgContainer, ph);
        }
    }

    function setPlaceholderContent(container, ph) {
        const devBadge=container.querySelector('.badge-overlay');
        const srcRef=container.querySelector('.src-ref-banner');
        container.innerHTML=`<div class="img-placeholder"><span class="material-icons-round">${ph.iconMI}</span></div><div class="img-veil"></div>`;
        if(devBadge) container.insertBefore(devBadge.cloneNode(true), container.firstChild);
        if(srcRef)   container.appendChild(srcRef.cloneNode(true));
    }

    /* ════════════════════════════ SEARCH ══ */
    function searchNews() {
        const q = document.getElementById('searchInput').value.trim()||'latest news';
        isTrendingActive=false; toggleLocationButtons(false);
        document.querySelectorAll('.cat-chip,.loc-chip').forEach(b=>b.classList.remove('active'));
        currentCategory=q; currentLocation='worldwide';
        setFilterBadge(`🔍 Search: ${esc(q)} · 🌐 Worldwide`);
        if(currentFetchController) currentFetchController.abort();
        fetchNews(q);
    }

    /* ════════════════════════════ DEVELOPING NEWS FETCH ══ */
    function extractKeywords(title) {
        const stops=['the','a','an','and','or','but','in','on','at','to','for','of','with','by','from','as','is','was','are','been','be','have','has','had','will','can','said','says','after','over','out','into'];
        let clean=title.toLowerCase().replace(/[^\w\s-]/g,' ');
        const words=clean.split(/\s+/).filter(w=>w.length>2&&!stops.includes(w));
        const proper=title.split(/\s+/).filter(w=>w.length>2&&w[0]===w[0].toUpperCase());
        return proper.length>0 ? proper.slice(0,4).join(' ') : words.slice(0,4).join(' ');
    }
    async function fetchDevelopingNews(mainArticle) {
        try {
            const kw=extractKeywords(mainArticle.title);
            const ctrl=new AbortController();
            const tid=setTimeout(()=>ctrl.abort(),8000);
            const r=await fetch(`rss_proxy_v3.php?q=${encodeURIComponent(kw)}`,{signal:ctrl.signal});
            clearTimeout(tid);
            if(!r.ok) throw new Error(`HTTP ${r.status}`);
            const xml=await r.text();
            const arts=parseXMLFeed(xml);
            return arts.filter(a=>a.title!==mainArticle.title).slice(0,5);
        } catch(e){ return []; }
    }

    /* ════════════════════════════ IMPORT HELPERS ══ */
    async function importSingleArticle(article) {
        const btn=document.createElement('button'); btn.style.display='none'; document.body.appendChild(btn);
        await saveArticle(article,btn);
        if(btn.parentNode) btn.remove();
    }
    function importFromButton(btnEl) {
        saveArticle({title:btnEl.dataset.title,link:btnEl.dataset.link,author:btnEl.dataset.author,
            pubDate:btnEl.dataset.pubdate,description:''}, btnEl);
    }
    function importAllNews() { saveAllVisibleArticles(); }

    /* ════════════════════════════ LOADING STATES ══ */
    function showLoadingState(msg, small=false) {
        const loading=document.getElementById('loading');
        const grid=document.getElementById('newsGrid');
        loading.style.display='block';
        loading.innerHTML=`<div class="loading-state">
            <div class="loading-ring"></div>
            <div class="loading-label">${small?`<span>${msg}</span>`:`Loading fresh news…<br><span>${msg}</span>`}</div>
        </div>`;
        grid.innerHTML='';
    }
    function hideLoading() { document.getElementById('loading').style.display='none'; }
    function showErrorState(title, msg) {
        const loading=document.getElementById('loading');
        loading.style.display='block';
        loading.innerHTML=`<div class="loading-state">
            <div style="width:60px;height:60px;border-radius:50%;background:var(--error-bg);display:flex;align-items:center;justify-content:center;margin-bottom:16px">
                <span class="material-icons-round" style="font-size:30px!important;color:#E11D48">error_outline</span>
            </div>
            <div class="loading-label"><strong style="color:var(--error-text)">${title}</strong><br><span>${msg}</span></div>
        </div>`;
    }

    /* ════════════════════════════ TEST DATA ══ */
    function loadTestData() {
        isTrendingActive=false; toggleLocationButtons(false);
        const testArticles=[
            {title:"Philippines Economy Shows Strong Growth in Q4 2025",link:"https://example.com/economy-growth",pubDate:new Date().toUTCString(),author:"Philippine Daily Inquirer"},
            {title:"New AI Technology Revolutionizes Healthcare in Manila",link:"https://example.com/ai-healthcare",pubDate:new Date(Date.now()-3600000).toUTCString(),author:"TechCrunch Philippines"},
            {title:"Typhoon Pepito Weakens, Moving Away from Luzon",link:"https://example.com/typhoon-update",pubDate:new Date(Date.now()-7200000).toUTCString(),author:"ABS-CBN News"},
            {title:"Philippine Basketball Team Wins Regional Championship",link:"https://example.com/basketball-win",pubDate:new Date(Date.now()-10800000).toUTCString(),author:"Rappler Sports"},
            {title:"New Infrastructure Projects Announced for Metro Manila",link:"https://example.com/infrastructure",pubDate:new Date(Date.now()-14400000).toUTCString(),author:"Business World"},
            {title:"Local Scientists Discover New Marine Species in Palawan",link:"https://example.com/marine-discovery",pubDate:new Date(Date.now()-18000000).toUTCString(),author:"Science Daily PH"},
            {title:"Filipino Startup Raises $10M in Series A Funding",link:"https://example.com/startup-funding",pubDate:new Date(Date.now()-21600000).toUTCString(),author:"Tech in Asia"},
            {title:"Department of Health Launches New Vaccination Program",link:"https://example.com/vaccination",pubDate:new Date(Date.now()-25200000).toUTCString(),author:"Manila Bulletin"},
            {title:"Cebu Tourism Industry Reports Record Numbers",link:"https://example.com/cebu-tourism",pubDate:new Date(Date.now()-28800000).toUTCString(),author:"SunStar Cebu"},
            {title:"New Film Festival Showcases Filipino Cinema Excellence",link:"https://example.com/film-festival",pubDate:new Date(Date.now()-32400000).toUTCString(),author:"Variety Asia"},
            {title:"Philippine Stock Exchange Reaches All-Time High",link:"https://example.com/stock-market",pubDate:new Date(Date.now()-36000000).toUTCString(),author:"Bloomberg Philippines"},
            {title:"Innovative Education Platform Launches in Mindanao",link:"https://example.com/education-tech",pubDate:new Date(Date.now()-39600000).toUTCString(),author:"EdTech Magazine"},
        ];

        const loading=document.getElementById('loading');
        loading.style.display='block';
        loading.innerHTML=`<div class="success-banner">
            <button class="close-x" onclick="this.parentElement.parentElement.style.display='none'"><span class="material-icons-round">close</span></button>
            <span class="material-icons-round">check_circle</span>
            <h3>Test Data Loaded Successfully</h3>
            <p>Showing 12 sample Philippine news articles. The live RSS feed may be temporarily unavailable.</p>
        </div>`;

        currentNews=testArticles;
        displayNews(currentNews.slice(0,displayedCount));
        updateStats();
        setTimeout(()=>{ const g=document.getElementById('newsGrid'); if(g?.children.length>0) g.scrollIntoView({behavior:'smooth',block:'start'}); },300);
    }

    /* ════════════════════════════ MISC ══ */
    function showDashboard() { window.location.href='http://newsnetwork.mbcradio.net/crud/user/user_dashboard.php'; }
    function refreshNews() {
        if (isTrendingActive) {
            const btn=document.querySelector('.cat-chip.hot');
            if(btn) selectPhilippinesTrending(btn);
        } else fetchNews(buildQuery());
    }

    function timeAgoJS(datetime) {
        const diff=(Date.now()-new Date(datetime).getTime())/1000;
        if(diff<60)    return 'Just now';
        if(diff<3600)  return Math.floor(diff/60)+'m ago';
        if(diff<86400) return Math.floor(diff/3600)+'h ago';
        return Math.floor(diff/86400)+'d ago';
    }
    function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }

    /* ════════════════════════════ SEARCH INPUT ══ */
    let searchT;
    document.getElementById('searchInput').addEventListener('input',()=>{
        clearTimeout(searchT); searchT=setTimeout(searchNews, 620);
    });
    document.getElementById('searchInput').addEventListener('keypress',e=>{ if(e.key==='Enter') searchNews(); });

    /* ════════════════════════════ INIT ══ */
    (function init(){
        const now=new Date();
        document.getElementById('currentDate').textContent=now.toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'});
        document.getElementById('loadTime').textContent=now.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'});
    })();

    window.onload=()=>{
        const btn=document.querySelector('.cat-chip.hot');
        if(btn) selectPhilippinesTrending(btn);
    };
</script>
</body>
</html>