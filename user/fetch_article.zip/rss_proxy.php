<?php
/**
 * RSS Proxy v3 - WITH DATE FILTERING
 * Filters to TODAY and YESTERDAY only
 */

// IMMEDIATE TEST - if you see this, the new file is working!
if (isset($_GET['test']) && $_GET['test'] === '1') {
    header('Content-Type: application/json');
    date_default_timezone_set('Asia/Manila');
    die(json_encode([
        'status' => 'NEW FILE WORKING!',
        'version' => 'v3-filtered',
        'uploaded' => date('Y-m-d H:i:s'),
        'timezone' => 'Asia/Manila',
        'today' => date('Y-m-d'),
        'yesterday' => date('Y-m-d', strtotime('-1 day')),
        'message' => 'If you see this, the new rss_proxy.php is correctly uploaded!'
    ], JSON_PRETTY_PRINT));
}

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

// Set timezone to Philippines
date_default_timezone_set('Asia/Manila');

// Get the RSS query from the URL parameter
$query = isset($_GET['q']) ? $_GET['q'] : 'Philippines news';

// Get today and yesterday dates
$todayDate = date('Y-m-d');
$yesterdayDate = date('Y-m-d', strtotime('-1 day'));

// Function to fetch RSS from Google News
function fetchRSS($url) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        CURLOPT_HTTPHEADER => [
            'Accept: application/xml, text/xml, application/rss+xml',
            'Accept-Language: en-US,en;q=0.9',
            'Cache-Control: no-cache'
        ]
    ]);
    
    $xmlContent = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200) {
        return $xmlContent;
    }
    return false;
}

// Function to parse RSS XML and extract items
function parseRSSItems($xmlContent) {
    $items = [];
    $xml = @simplexml_load_string($xmlContent);
    
    if ($xml === false) return $items;
    
    if (isset($xml->channel->item)) {
        foreach ($xml->channel->item as $item) {
            $items[] = [
                'title' => (string)$item->title,
                'link' => (string)$item->link,
                'pubDate' => (string)$item->pubDate,
                'description' => (string)$item->description,
                'source' => isset($item->source) ? (string)$item->source : ''
            ];
        }
    }
    
    return $items;
}

// Function to get article date in Y-m-d format
function getArticleDate($pubDate) {
    $timestamp = strtotime($pubDate);
    if ($timestamp === false) return null;
    return date('Y-m-d', $timestamp);
}

// Check if article is from today or yesterday ONLY
function isAllowedDate($pubDate, $todayDate, $yesterdayDate) {
    $articleDate = getArticleDate($pubDate);
    if ($articleDate === null) return false;
    return ($articleDate === $todayDate || $articleDate === $yesterdayDate);
}

// Check if article is from today
function isToday($pubDate, $todayDate) {
    return (getArticleDate($pubDate) === $todayDate);
}

// Remove duplicate articles
function removeDuplicates($items) {
    $unique = [];
    $seen = [];
    
    foreach ($items as $item) {
        $key = strtolower(preg_replace('/[^a-z0-9]/i', '', $item['title']));
        if (!isset($seen[$key]) && strlen($key) > 20) {
            $seen[$key] = true;
            $unique[] = $item;
        }
    }
    
    return $unique;
}

// Build RSS XML output
function buildRSSXml($items, $query, $todayDate, $yesterdayDate) {
    $xml = '<?xml version="1.0" encoding="UTF-8"?>';
    $xml .= '<rss version="2.0">';
    $xml .= '<channel>';
    $xml .= '<generator>RSS-Proxy-v3-Filtered</generator>';
    $xml .= '<title>Filtered News: ' . htmlspecialchars($query) . '</title>';
    $xml .= '<description>Only articles from ' . $todayDate . ' and ' . $yesterdayDate . '</description>';
    $xml .= '<lastBuildDate>' . date('r') . '</lastBuildDate>';
    
    foreach ($items as $item) {
        $xml .= '<item>';
        $xml .= '<title>' . htmlspecialchars($item['title']) . '</title>';
        $xml .= '<link>' . htmlspecialchars($item['link']) . '</link>';
        $xml .= '<pubDate>' . htmlspecialchars($item['pubDate']) . '</pubDate>';
        $xml .= '<description>' . htmlspecialchars($item['description']) . '</description>';
        if (!empty($item['source'])) {
            $xml .= '<source>' . htmlspecialchars($item['source']) . '</source>';
        }
        $xml .= '</item>';
    }
    
    $xml .= '</channel>';
    $xml .= '</rss>';
    
    return $xml;
}

// === MAIN LOGIC ===

$allItems = [];

// Fetch from multiple sources
$urls = [
    'https://news.google.com/rss/search?q=' . urlencode($query . ' when:1d') . '&hl=en-PH&gl=PH&ceid=PH:en',
    'https://news.google.com/rss/search?q=' . urlencode($query . ' when:2d') . '&hl=en-PH&gl=PH&ceid=PH:en',
    'https://news.google.com/rss/search?q=' . urlencode($query) . '&hl=en-PH&gl=PH&ceid=PH:en',
];

foreach ($urls as $url) {
    $content = fetchRSS($url);
    if ($content) {
        $items = parseRSSItems($content);
        $allItems = array_merge($allItems, $items);
    }
}

// Remove duplicates
$allItems = removeDuplicates($allItems);

// STRICT FILTER: Only today and yesterday
$filteredItems = [];
foreach ($allItems as $item) {
    if (isAllowedDate($item['pubDate'], $todayDate, $yesterdayDate)) {
        $filteredItems[] = $item;
    }
}
$allItems = $filteredItems;

// Sort: Today first, then yesterday
usort($allItems, function($a, $b) use ($todayDate) {
    $aIsToday = isToday($a['pubDate'], $todayDate);
    $bIsToday = isToday($b['pubDate'], $todayDate);
    
    if ($aIsToday && !$bIsToday) return -1;
    if (!$aIsToday && $bIsToday) return 1;
    
    return strtotime($b['pubDate']) - strtotime($a['pubDate']);
});

// Output
header('Content-Type: application/xml; charset=utf-8');
echo buildRSSXml($allItems, $query, $todayDate, $yesterdayDate);
